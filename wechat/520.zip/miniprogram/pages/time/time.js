// pages/time/time.js
const db = wx.cloud.database()
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    fall_in_love: false,
    time_in_love: new Date(),
    // date: '2018-09-25',
    date: new Date().getFullYear() + "-" + new Date().getDay() + "-" + new Date().getDate(),
    time: '0:00',
    local:false
  },
  /*21：12 */
  select_icon() {
    this.setData({
      select_icon: true
    })
  },
  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  start_love() {
    this.setData({
      fall_in_love: true
    })
    var sl_data = {
      fall_in_love: this.data.fall_in_love,
      date: this.data.date,
      time: this.data.time
    }
    db.collection('user').add({
      data:{
        start_love_data: sl_data
      },
      success(res){
        console.log("云存储完成",res)
      }
    })
    wx.setStorage({
      key: 'start_love',
      data: sl_data,
      success:res=>{
        console.log("本地存储完成",res)
        this.setData({
          local:true
        })
      }
    })
  },
  bindTimeChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      time: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function(options) {
    wx.getStorage({
      key: 'start_love',
      success:res=>{
        this.setData({
          fall_in_love:res.data.fall_in_love,
          date:res.data.date,
          time:res.data.time,
          local:true
        })
      },
    })
    if(!this.data.local){
      console.log("本地没有，云端下载数据")
      db.collection('user').where({
        _openid: app.globalData.openid
      }).get({
        success:res=> {
          this.setData({
            date:res.data[0].start_love_data.date,
            time: res.data[0].start_love_data.time,
            fall_in_love: res.data[0].start_love_data.fall_in_love,
            local:true
          })
          console.log("云端下载完成，并进行本地存储")
          wx.getStorage({
            key: 'start_love',
            success: res => {
              this.setData({
                fall_in_love: res.data.fall_in_love,
                date: res.data.date,
                time: res.data.time,
                local: true
              })
            },
          })
        },
        fail(res){
          console.log("云端也没有")
        }
      })
    }
    
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})