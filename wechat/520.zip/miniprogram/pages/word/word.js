// pages/word/word.js
const db = wx.cloud.database()
const word = db.collection('word')

const {
  $Message
} = require('../../dist/base/index');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    search_name: '',
    word_list: [],
    search_result: [],
    pop_show: false,
    item_id: "",
  },
  /**
   * 生命周期函数--监听页面加载
   */
  del_word(e) {
    wx.showModal({
      content: '删除了将无法恢复哦',
      success:res=> {
        if (res.confirm) {
          word.doc(e.currentTarget.dataset.id).remove({
            success:res=>{
              wx.showToast({
                title: '删除成功',
              })
              var index = e.currentTarget.dataset.index
              var list = this.data.word_list
              list.splice(index,1)
              this.setData({
                word_list:list
              })
            }
          })
        } else if (res.cancel) {
          console.log('取消')
        }
      }
    })
  },
  onSearch(e) {
    var search = e.detail
    if (search == "") {

    } else {
      word.where({
        word: db.RegExp({
          regexp: search,
          options: 'i'
        })
      }).get({
        success: res => {
          this.setData({
            search_result: res.data,
            pop_show: true
          })
        }
      })
    }
  },
  swipeonClose(event) {
    const {
      position,
      instance
    } = event.detail;
    switch (position) {
      case 'cell':
        instance.close();
        break;
      case 'right':
        instance.close();
        break;
    }
  },
  onCancel(e) {
    console.log(e)
  },
  showPopup() {
    this.setData({
      pop_show: true
    });
  },

  onClose() {
    this.setData({
      pop_show: false
    });
  },
  onLoad: function(options) {
    word.get({
      success: res => {
        this.setData({
          word_list: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    word.get({
      success: res => {
        this.setData({
          word_list: res.data
        })
        console.log(res)
      },
      fail(res) {
        console.log(res)
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})